package com.luma.clone

import android.content.Context

/**
 * 进程内的共享运行时状态：
 *  - settings 被悬浮面板修改，采集线程每帧读取（同一个对象引用，改完即时生效）
 *  - 其余字段由采集线程写入，悬浮面板每秒读一次用于显示
 */
object State {

    val settings = AimSettings()

    @Volatile var modelReady = false
    @Volatile var fps = 0
    @Volatile var detectMs = 0L
    @Volatile var targets = 0
    @Volatile var channel = "未初始化"
    @Volatile var running = false

    private const val PREF = "cfg"

    fun load(c: Context) {
        val sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        settings.fovPx = sp.getFloat("fov", settings.fovPx)
        settings.smooth = sp.getFloat("smooth", settings.smooth)
        settings.headRatio = sp.getFloat("head", settings.headRatio)
        settings.maxStepPx = sp.getFloat("step", settings.maxStepPx)
        settings.confTh = sp.getFloat("conf", settings.confTh)
        settings.nmsIou = sp.getFloat("iou", settings.nmsIou)
    }

    fun save(c: Context) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putFloat("fov", settings.fovPx)
            .putFloat("smooth", settings.smooth)
            .putFloat("head", settings.headRatio)
            .putFloat("step", settings.maxStepPx)
            .putFloat("conf", settings.confTh)
            .putFloat("iou", settings.nmsIou)
            .apply()
    }
}
