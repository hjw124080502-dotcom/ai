package com.luma.clone

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.Log
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** 检测目标，坐标已归一化到 0..1（相对原画面，已去 letterbox 偏移）。 */
data class Target(
    val cx: Float,
    val cy: Float,
    val w: Float,
    val h: Float,
    val score: Float,
    val cls: Int
)

/**
 * ONNX Runtime 推理（模型：6AY_v26m_0917_256x256.onnx，producer=pytorch 2.12，输入名 images）。
 *
 * - 输入尺寸运行时从 ORT 的 inputInfo 读取，读不到则按 256。
 * - 预处理用 letterbox（等比缩放 + 灰边），坐标回映时扣除 padding，避免非方形屏幕下瞄点偏移。
 * - 输出形状自适应：[1,C,N] 或 [1,N,C]；C==5 视为单类目标度，C>6 多类取最大值。
 */
class Detector(context: Context) {

    companion object {
        private const val TAG = "Detector"
        const val DEFAULT_INPUT = 256
        const val MODEL_ASSET = "model.onnx"
        const val MODEL_FILE = "model.onnx"
    }

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()

    private val session: OrtSession? = runCatching {
        val bytes = loadModel(context)
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(4)
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        env.createSession(bytes, opts)
    }.onFailure { Log.e(TAG, "session failed", it) }.getOrNull()

    val available: Boolean get() = session != null

    private val inName: String? = session?.inputNames?.firstOrNull()

    /** 运行时探测输入尺寸。 */
    val inputH: Int
    val inputW: Int

    init {
        var h = DEFAULT_INPUT
        var w = DEFAULT_INPUT
        runCatching {
            val info = inName?.let { session?.inputInfo?.get(it) }?.info as? TensorInfo
            val s = info?.shape
            if (s != null && s.size == 4) {
                if (s[2] > 0) h = s[2].toInt()
                if (s[3] > 0) w = s[3].toInt()
            }
            Log.i(TAG, "input name=$inName shape=${s?.toList()}")
        }
        inputH = h
        inputW = w
    }

    private fun loadModel(context: Context): ByteArray {
        runCatching { context.assets.open(MODEL_ASSET).use { return it.readBytes() } }
        val f = File(context.filesDir, MODEL_FILE)
        if (f.exists()) return f.readBytes()
        throw IllegalStateException("model.onnx not found (assets or filesDir)")
    }

    private val inBuf: FloatBuffer =
        ByteBuffer.allocateDirect(3 * inputW * inputH * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()

    private val pix = IntArray(inputW * inputH)

    /** letterbox 后的画布，复用避免每帧分配。 */
    private val canvasBmp: Bitmap by lazy {
        Bitmap.createBitmap(inputW, inputH, Bitmap.Config.ARGB_8888)
    }
    private val canvas: Canvas by lazy { Canvas(canvasBmp) }
    private val paint: Paint by lazy {
        Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    }

    fun detect(src: Bitmap, confTh: Float = 0.35f, iouTh: Float = 0.45f): List<Target> {
        val sess = session ?: return emptyList()
        val name = inName ?: return emptyList()

        // ---- letterbox ----
        val scale = min(inputW.toFloat() / src.width, inputH.toFloat() / src.height)
        val nw = max(1, (src.width * scale).roundToInt())
        val nh = max(1, (src.height * scale).roundToInt())
        val padX = (inputW - nw) / 2f
        val padY = (inputH - nh) / 2f

        canvas.drawColor(Color.rgb(114, 114, 114))
        canvas.drawBitmap(
            src, null,
            android.graphics.RectF(padX, padY, padX + nw, padY + nh),
            paint
        )
        canvasBmp.getPixels(pix, 0, inputW, 0, 0, inputW, inputH)

        // ---- NCHW 填图 0..1 ----
        inBuf.rewind()
        for (p in pix) inBuf.put(((p shr 16) and 0xFF) / 255f)
        for (p in pix) inBuf.put(((p shr 8) and 0xFF) / 255f)
        for (p in pix) inBuf.put((p and 0xFF) / 255f)
        inBuf.rewind()

        val shape = longArrayOf(1, 3, inputH.toLong(), inputW.toLong())
        val tensor = OnnxTensor.createTensor(env, inBuf, shape)
        try {
            val res = sess.run(mapOf(name to tensor))
            try {
                val out = res.get(0) as OnnxTensor
                val dims = ((out.info as? TensorInfo)?.shape) ?: longArrayOf()
                val data = out.floatBuffer
                val total = data.remaining()

                val a = dims.getOrNull(1)?.toInt() ?: 0
                val b = dims.getOrNull(2)?.toInt() ?: 0
                val channelsFirst = a in 5..2048 && a < b
                val c = if (channelsFirst) a else b
                val n = if (channelsFirst) b else a
                if (c == 0 || n == 0 || c.toLong() * n != total.toLong()) {
                    Log.w(TAG, "unexpected output dims ${dims.toList()} total=$total")
                    return emptyList()
                }

                fun at(ch: Int, i: Int): Float =
                    if (channelsFirst) data.get(ch * n + i) else data.get(i * c + ch)

                val classes = c - 4
                val out2 = ArrayList<Target>(64)
                for (i in 0 until n) {
                    var bestCls = -1
                    var bestScore = confTh
                    if (classes <= 1) {
                        val v = at(4, i)
                        if (v > bestScore) { bestScore = v; bestCls = 0 }
                    } else {
                        for (k in 4 until c) {
                            val v = at(k, i)
                            if (v > bestScore) { bestScore = v; bestCls = k - 4 }
                        }
                    }
                    if (bestCls < 0) continue

                    // letterbox 空间 -> 原图归一化
                    val cxLb = at(0, i)
                    val cyLb = at(1, i)
                    val wLb = at(2, i)
                    val hLb = at(3, i)

                    val cxN = (cxLb - padX) / nw
                    val cyN = (cyLb - padY) / nh
                    val wN = wLb / nw
                    val hN = hLb / nh

                    if (cxN < -0.2f || cxN > 1.2f || cyN < -0.2f || cyN > 1.2f) continue

                    out2.add(Target(cxN, cyN, wN, hN, bestScore, bestCls))
                }
                return nms(out2, iouTh)
            } finally {
                res.close()
            }
        } finally {
            tensor.close()
        }
    }

    /** 按类别做贪心 NMS（归一化坐标）。 */
    private fun nms(list: List<Target>, iouTh: Float): List<Target> {
        if (list.size <= 1) return list
        val out = ArrayList<Target>(list.size)
        for ((_, group) in list.groupBy { it.cls }) {
            val sorted = group.sortedByDescending { it.score }.toMutableList()
            while (sorted.isNotEmpty()) {
                val best = sorted.removeAt(0)
                out.add(best)
                sorted.removeAll { iou(best, it) > iouTh }
            }
        }
        return out
    }

    private fun iou(a: Target, b: Target): Float {
        val ax1 = a.cx - a.w / 2f; val ay1 = a.cy - a.h / 2f
        val ax2 = a.cx + a.w / 2f; val ay2 = a.cy + a.h / 2f
        val bx1 = b.cx - b.w / 2f; val by1 = b.cy - b.h / 2f
        val bx2 = b.cx + b.w / 2f; val by2 = b.cy + b.h / 2f

        val iw = minOf(ax2, bx2) - maxOf(ax1, bx1)
        val ih = minOf(ay2, by2) - maxOf(ay1, by1)
        if (iw <= 0f || ih <= 0f) return 0f
        val inter = iw * ih
        val uni = a.w * a.h + b.w * b.h - inter
        return if (uni <= 0f) 0f else inter / uni
    }

    fun close() {
        runCatching { session?.close() }
    }
}
