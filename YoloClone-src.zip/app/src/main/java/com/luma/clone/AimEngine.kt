package com.luma.clone

import kotlin.math.abs
import kotlin.math.hypot

/** 瞄准参数，全部可运行时调。 */
data class AimSettings(
    var fovPx: Float = 400f,        // 搜索半径（屏幕像素）
    var smooth: Float = 0.35f,      // 0..1，越小越平滑
    var headRatio: Float = 0.28f,   // 瞄头：框顶部向下偏移比例
    var maxStepPx: Float = 60f,     // 单帧最大位移，防抖动
    var confTh: Float = 0.35f,      // 置信度阈值（后处理）
    var nmsIou: Float = 0.45f       // NMS IoU 阈值
)

/**
 * Target 坐标为 0..1 归一化，这里换算到屏幕像素后选靶、算位移。
 */
class AimEngine(val settings: AimSettings = AimSettings()) {

    fun pick(targets: List<Target>, screenW: Int, screenH: Int): Target? {
        if (targets.isEmpty()) return null
        val cx = screenW / 2f
        val cy = screenH / 2f

        var best: Target? = null
        var bestD = Float.MAX_VALUE
        for (t in targets) {
            val p = aimPointPx(t, screenW, screenH)
            val d = hypot(p.first - cx, p.second - cy)
            if (d > settings.fovPx) continue
            if (d < bestD) { bestD = d; best = t }
        }
        return best
    }

    /** 返回 (dx, dy)：本帧应注入的位移，已平滑与限幅。 */
    fun delta(t: Target, screenW: Int, screenH: Int): Pair<Float, Float> {
        val cx = screenW / 2f
        val cy = screenH / 2f
        val p = aimPointPx(t, screenW, screenH)

        var dx = (p.first - cx) * settings.smooth
        var dy = (p.second - cy) * settings.smooth

        val len = hypot(dx, dy)
        if (len > settings.maxStepPx) {
            val k = settings.maxStepPx / len
            dx *= k; dy *= k
        }
        if (abs(dx) < 2f) dx = 0f
        if (abs(dy) < 2f) dy = 0f
        return dx to dy
    }

    fun distance(t: Target, screenW: Int, screenH: Int): Float {
        val p = aimPointPx(t, screenW, screenH)
        return hypot(p.first - screenW / 2f, p.second - screenH / 2f)
    }

    /** 瞄准点：先取框中心，再按 headRatio 上移（默认识别为“身体框、瞄头”）。 */
    private fun aimPointPx(t: Target, screenW: Int, screenH: Int): Pair<Float, Float> {
        val x = t.cx * screenW
        val y = t.cy * screenH - t.h * screenH * (0.5f - settings.headRatio)
        return x to y
    }
}
