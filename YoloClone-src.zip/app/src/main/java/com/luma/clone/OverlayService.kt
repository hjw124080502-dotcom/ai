package com.luma.clone

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.roundToInt

/** 悬浮控制面板：滑块实时绑定 State.settings，顶部实时状态每秒刷新。 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var rootView: View? = null
    private lateinit var lp: WindowManager.LayoutParams

    private lateinit var statusView: TextView
    private lateinit var fovLabel: TextView
    private lateinit var smoothLabel: TextView
    private lateinit var headLabel: TextView
    private lateinit var confLabel: TextView

    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refreshStatus()
            ui.postDelayed(this, 500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        State.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        show()
        ui.post(tick)
    }

    private fun show() {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 32
            y = 240
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC000000.toInt())
            setPadding(28, 20, 28, 24)
        }

        val title = TextView(this).apply {
            text = "YoloClone  ▸ 拖动我"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 15f
            setPadding(0, 0, 0, 8)
            setOnTouchListener(object : View.OnTouchListener {
                private var dx = 0f
                private var dy = 0f
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> {
                            dx = e.rawX - lp.x
                            dy = e.rawY - lp.y
                            return true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            lp.x = (e.rawX - dx).toInt()
                            lp.y = (e.rawY - dy).toInt()
                            rootView?.let { wm.updateViewLayout(it, lp) }
                            return true
                        }
                    }
                    return false
                }
            })
        }
        panel.addView(title)

        statusView = TextView(this).apply {
            setTextColor(0xFF7FD1FF.toInt())
            textSize = 12f
            setPadding(0, 0, 0, 10)
            text = "初始化…"
        }
        panel.addView(statusView)

        // ---- FOV ----
        fovLabel = label("")
        panel.addView(fovLabel)
        panel.addView(SeekBar(this).apply {
            max = 100
            progress = fovToProgress(State.settings.fovPx)
            setOnSeekBarChangeListener(object : SimpleSeek {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    State.settings.fovPx = 100f + p * 9f          // 100..1000 px
                    fovLabel.text = "FOV：${State.settings.fovPx.roundToInt()} px"
                    State.save(this@OverlayService)
                }
            })
        })

        // ---- 平滑 ----
        smoothLabel = label("")
        panel.addView(smoothLabel)
        panel.addView(SeekBar(this).apply {
            max = 75
            progress = ((State.settings.smooth - 0.05f) / 0.01f).roundToInt().coerceIn(0, 75)
            setOnSeekBarChangeListener(object : SimpleSeek {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    State.settings.smooth = 0.05f + p * 0.01f      // 0.05..0.80
                    smoothLabel.text = "平滑：${String.format("%.2f", State.settings.smooth)}"
                    State.save(this@OverlayService)
                }
            })
        })

        // ---- 瞄头比例 ----
        headLabel = label("")
        panel.addView(headLabel)
        panel.addView(SeekBar(this).apply {
            max = 50
            progress = (State.settings.headRatio * 100f).roundToInt().coerceIn(0, 50)
            setOnSeekBarChangeListener(object : SimpleSeek {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    State.settings.headRatio = p / 100f            // 0..0.50
                    headLabel.text = "瞄头：${String.format("%.2f", State.settings.headRatio)}"
                    State.save(this@OverlayService)
                }
            })
        })

        // ---- 置信度 ----
        confLabel = label("")
        panel.addView(confLabel)
        panel.addView(SeekBar(this).apply {
            max = 80
            progress = ((State.settings.confTh - 0.10f) / 0.01f).roundToInt().coerceIn(0, 80)
            setOnSeekBarChangeListener(object : SimpleSeek {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    State.settings.confTh = 0.10f + p * 0.01f      // 0.10..0.90
                    confLabel.text = "置信度：${String.format("%.2f", State.settings.confTh)}"
                    State.save(this@OverlayService)
                }
            })
        })

        panel.addView(Button(this).apply {
            text = "主界面 / 屏录授权"
            setOnClickListener {
                startActivity(
                    Intent(this@OverlayService, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        })

        panel.addView(Button(this).apply {
            text = "停止采集"
            setOnClickListener {
                stopService(Intent(this@OverlayService, ScreenCaptureService::class.java))
            }
        })

        panel.addView(Button(this).apply {
            text = "关闭面板"
            setOnClickListener { stopSelf() }
        })

        rootView = panel
        wm.addView(panel, lp)
        refreshLabels()
    }

    private fun fovToProgress(fov: Float): Int = ((fov - 100f) / 9f).roundToInt().coerceIn(0, 100)

    private fun refreshLabels() {
        fovLabel.text = "FOV：${State.settings.fovPx.roundToInt()} px"
        smoothLabel.text = "平滑：${String.format("%.2f", State.settings.smooth)}"
        headLabel.text = "瞄头：${String.format("%.2f", State.settings.headRatio)}"
        confLabel.text = "置信度：${String.format("%.2f", State.settings.confTh)}"
    }

    private fun refreshStatus() {
        val model = if (State.modelReady) "已加载" else "未找到 model.onnx"
        statusView.text = buildString {
            append("模型：$model\n")
            append("通道：${State.channel}\n")
            append("FPS：${State.fps}   推理：${State.detectMs} ms\n")
            append("目标：${State.targets}   状态：${if (State.running) "运行中" else "未启动"}")
        }
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        setTextColor(0xFFCCCCCC.toInt())
        textSize = 12f
    }

    override fun onDestroy() {
        ui.removeCallbacks(tick)
        rootView?.let { runCatching { wm.removeView(it) } }
        rootView = null
        super.onDestroy()
    }

    /** SeekBar 监听器空实现，避免写三个完整接口。 */
    private interface SimpleSeek : SeekBar.OnSeekBarChangeListener {
        override fun onStartTrackingTouch(sb: SeekBar?) {}
        override fun onStopTrackingTouch(sb: SeekBar?) {}
    }
}
