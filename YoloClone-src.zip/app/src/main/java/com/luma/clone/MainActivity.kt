package com.luma.clone

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var projectionManager: MediaProjectionManager? = null

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val i = Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_START
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
                }
                startForegroundService(i)
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "采集已启动", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "未授权屏幕捕获", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(MediaProjectionManager::class.java)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        val title = TextView(this).apply {
            text = "YoloClone\n无授权、无卡密、无网络校验"
            textSize = 18f
        }
        root.addView(title)

        root.addView(Button(this).apply {
            text = "① 授予悬浮窗权限"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, null)
                )
            }
        })

        root.addView(Button(this).apply {
            text = "② 开启无障碍（无 root 时的注入通道）"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        root.addView(Button(this).apply {
            text = "③ 开始（选择屏幕）"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "先授予悬浮窗权限", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                projectionManager?.createScreenCaptureIntent()?.let(projectionLauncher::launch)
            }
        })

        root.addView(Button(this).apply {
            text = "停止"
            setOnClickListener {
                stopService(Intent(this, ScreenCaptureService::class.java))
                stopService(Intent(this, OverlayService::class.java))
            }
        })

        setContentView(root)
    }
}
