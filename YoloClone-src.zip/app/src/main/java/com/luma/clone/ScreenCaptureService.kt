package com.luma.clone

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager

/**
 * 采集 + 推理 + 瞄准主循环。
 * 对应原 app 的 CaptureService + 引擎调度部分（同进程，无 Binder 握手）。
 */
class ScreenCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.luma.clone.START"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        private const val CH_ID = "capture"
        private const val CH_NAME = "屏幕采集"
        private const val NOTI_ID = 1001
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    private lateinit var detector: Detector
    private val aim = AimEngine(State.settings)
    private val injector = TouchInjector()

    private var screenW = 0
    private var screenH = 0
    private var lastFrameAt = 0L
    private var frameIntervalMs = 33L

    @Volatile
    var running = false
        private set

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        State.load(this)
        detector = Detector(this)
        State.modelReady = detector.available
        thread = HandlerThread("aim-loop").also { it.start() }
        handler = Handler(thread!!.looper)
        createChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTI_ID,
                buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTI_ID, buildNotification())
        }
        injector.probeRoot()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                if (data != null) startProjection(code, data)
            }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun displayMetrics(): DisplayMetrics {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        return m
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        val m = displayMetrics()
        screenW = m.widthPixels
        screenH = m.heightPixels
        injector.init(screenW, screenH)
        State.channel = when {
            injector.uinputReady -> "uinput"
            injector.rootAvailable -> "su input"
            AccessibilityInjector.ready -> "无障碍"
            else -> "无通道"
        }
        State.running = true

        val mgr = getSystemService(MediaProjectionManager::class.java)
        projection = mgr.getMediaProjection(resultCode, data) ?: return

        reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection!!.createVirtualDisplay(
            "clone-capture",
            screenW, screenH, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null
        )

        running = true
        reader!!.setOnImageAvailableListener({ r -> onFrame(r) }, handler)
    }

    private fun onFrame(r: ImageReader) {
        val now = System.currentTimeMillis()
        if (now - lastFrameAt < frameIntervalMs) {
            r.acquireLatestImage()?.close()
            return
        }
        if (lastFrameAt > 0L) {
            State.fps = (1000f / (now - lastFrameAt).coerceAtLeast(1L)).toInt()
        }
        lastFrameAt = now

        val image = r.acquireLatestImage() ?: return
        try {
            val plane = image.planes[0]
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride
            val width = image.width
            val height = image.height
            val padded = rowStride / pixelStride

            val paddedBmp = Bitmap.createBitmap(padded, height, Bitmap.Config.ARGB_8888)
            paddedBmp.copyPixelsFromBuffer(plane.buffer)
            val bmp = Bitmap.createBitmap(paddedBmp, 0, 0, width, height)
            if (paddedBmp != bmp) paddedBmp.recycle()

            val t0 = System.nanoTime()
            val targets = detector.detect(bmp, State.settings.confTh, State.settings.nmsIou)
            State.detectMs = (System.nanoTime() - t0) / 1_000_000
            State.targets = targets.size
            val best = aim.pick(targets, width, height)

            if (best != null) {
                val (dx, dy) = aim.delta(best, width, height)
                if (dx != 0f || dy != 0f) {
                    injector.moveBy(dx, dy)
                }
            }
            bmp.recycle()
        } catch (t: Throwable) {
            // 单帧失败不能打死循环
        } finally {
            image.close()
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH_ID, CH_NAME, NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(): Notification {
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CH_ID) else Notification.Builder(this)
        return b.setContentTitle("YoloClone 采集中")
            .setContentText(if (detector.available) "模型已加载" else "未找到模型（空跑）")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        running = false
        State.running = false
        State.fps = 0
        State.targets = 0
        reader?.setOnImageAvailableListener(null, null)
        virtualDisplay?.release()
        projection?.stop()
        reader?.close()
        detector.close()
        injector.release()
        thread?.quitSafely()
        super.onDestroy()
    }
}
