package com.luma.clone

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * uinput 原生通道（对应原 app 的 libaimuinput.so）。
 * 直接把 ABS_MT 事件写内核，不经过 InputManager，延迟与原生实现同一量级。
 * 需要能打开 /dev/uinput（root 或 adb chmod）。
 */
object UinputInjector {

    private const val TAG = "Uinput"
    private var loaded = false
    private var fd = -1

    init {
        loaded = runCatching { System.loadLibrary("aimuinput"); true }.getOrDefault(false)
    }

    val libraryLoaded: Boolean get() = loaded
    val ready: Boolean get() = loaded && fd >= 0

    /** 尝试创建设备；失败时用 root 放一次权限再试。 */
    fun ensureDevice(exec: (String) -> Pair<Int, String>, maxX: Int, maxY: Int): Boolean {
        if (!loaded) return false
        if (fd >= 0) return true

        var f = runCatching { nativeOpen(maxX, maxY) }.getOrDefault(-1)
        if (f < 0) {
            val (rc, _) = exec("su -c 'chmod 666 /dev/uinput'")
            Log.i(TAG, "chmod /dev/uinput rc=$rc")
            f = runCatching { nativeOpen(maxX, maxY) }.getOrDefault(-1)
        }
        fd = f
        Log.i(TAG, "uinput fd=$fd")
        return fd >= 0
    }

    fun drag(x1: Float, y1: Float, x2: Float, y2: Float, ms: Int = 16): Boolean {
        if (fd < 0) return false
        return runCatching { nativeDrag(fd, x1, y1, x2, y2, ms) }.getOrDefault(false)
    }

    fun release() {
        if (fd >= 0) runCatching { nativeClose(fd) }
        fd = -1
    }

    private external fun nativeOpen(maxX: Int, maxY: Int): Int
    private external fun nativeDrag(
        fd: Int, x1: Float, y1: Float, x2: Float, y2: Float, ms: Int
    ): Boolean
    private external fun nativeClose(fd: Int)
}

/**
 * 触摸注入三级后备：
 *   1) uinput （最快，需 root）
 *   2) su -c input swipe （需 root）
 *   3) dispatchGesture （无障碍，免 root）
 */
class TouchInjector {

    @Volatile
    var uinputReady: Boolean = false
        private set

    @Volatile
    var rootAvailable: Boolean = false
        private set

    private var screenW = 0
    private var screenH = 0

    fun probeRoot(): Boolean {
        rootAvailable = try {
            exec("su -c id").first == 0
        } catch (t: Throwable) {
            false
        }
        return rootAvailable
    }

    fun init(screenW: Int, screenH: Int) {
        this.screenW = screenW
        this.screenH = screenH
        if (!rootAvailable) probeRoot()
        uinputReady = UinputInjector.ensureDevice(::exec, screenW, screenH)
        Log.i("TouchInjector", "root=$rootAvailable uinput=$uinputReady a11y=${AccessibilityInjector.ready}")
    }

    private fun exec(cmd: String): Pair<Int, String> = try {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
        val out = p.inputStream.bufferedReader().use { it.readText() }
        p.waitFor() to out
    } catch (t: Throwable) {
        -1 to ""
    }

    /** 相对移动：从屏幕中心拖动 (dx,dy)。 */
    fun moveBy(dx: Float, dy: Float): Boolean {
        if (dx == 0f && dy == 0f) return true
        val cx = screenW / 2f
        val cy = screenH / 2f
        val tx = (cx + dx).coerceIn(0f, screenW - 1f)
        val ty = (cy + dy).coerceIn(0f, screenH - 1f)

        if (uinputReady && UinputInjector.drag(cx, cy, tx, ty, 16)) return true

        if (rootAvailable) {
            val (rc, _) = exec(
                "su -c 'input swipe ${cx.toInt()} ${cy.toInt()} ${tx.toInt()} ${ty.toInt()} 16'"
            )
            if (rc == 0) return true
        }
        return AccessibilityInjector.swipe(cx, cy, tx, ty)
    }

    fun release() {
        UinputInjector.release()
        uinputReady = false
    }
}

/** 无障碍回退通道。需在系统设置里开启本服务。 */
class AccessibilityInjector : AccessibilityService() {

    override fun onServiceConnected() {
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    companion object {
        @Volatile
        private var instance: AccessibilityInjector? = null

        val ready: Boolean get() = instance != null

        fun swipe(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
            val svc = instance ?: return false
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false

            val path = Path().apply {
                moveTo(x1, y1)
                lineTo(x2, y2)
            }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 16))
                .build()
            return svc.dispatchGesture(gesture, null, null)
        }
    }
}
