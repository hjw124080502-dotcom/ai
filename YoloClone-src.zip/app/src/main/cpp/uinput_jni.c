#include <jni.h>
#include <linux/uinput.h>
#include <linux/input.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <android/log.h>

#define TAG "aimuinput"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static int emit(int fd, int type, int code, int val) {
    struct input_event ie;
    memset(&ie, 0, sizeof(ie));
    ie.type = (unsigned short) type;
    ie.code = (unsigned short) code;
    ie.value = val;
    ssize_t n = write(fd, &ie, sizeof(ie));
    return n == (ssize_t) sizeof(ie) ? 0 : -1;
}

static void sleep_us(long us) {
    struct timespec ts;
    ts.tv_sec = us / 1000000L;
    ts.tv_nsec = (us % 1000000L) * 1000L;
    nanosleep(&ts, NULL);
}

/**
 * 打开并注册一个虚拟多点触摸设备。
 * 返回 fd（>=0）成功，-1 失败。
 */
jint JNICALL
Java_com_luma_clone_UinputInjector_nativeOpen(JNIEnv *env, jclass clazz, jint maxX, jint maxY) {
    (void) env; (void) clazz;

    int fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
    if (fd < 0) {
        LOGE("open /dev/uinput failed: %s", strerror(errno));
        return -1;
    }

    ioctl(fd, UI_SET_EVBIT, EV_SYN);
    ioctl(fd, UI_SET_EVBIT, EV_KEY);
    ioctl(fd, UI_SET_EVBIT, EV_ABS);

    ioctl(fd, UI_SET_KEYBIT, BTN_TOUCH);
    ioctl(fd, UI_SET_ABSBIT, ABS_MT_SLOT);
    ioctl(fd, UI_SET_ABSBIT, ABS_MT_TRACKING_ID);
    ioctl(fd, UI_SET_ABSBIT, ABS_MT_POSITION_X);
    ioctl(fd, UI_SET_ABSBIT, ABS_MT_POSITION_Y);
    ioctl(fd, UI_SET_ABSBIT, ABS_MT_PRESSURE);
    ioctl(fd, UI_SET_PROPBIT, INPUT_PROP_DIRECT);

    struct uinput_user_dev dev;
    memset(&dev, 0, sizeof(dev));
    snprintf(dev.name, UINPUT_MAX_NAME_SIZE, "aimuinput");
    dev.id.bustype = BUS_VIRTUAL;
    dev.id.vendor = 0x1209;
    dev.id.product = 0x0001;
    dev.id.version = 1;

    dev.absmax[ABS_MT_POSITION_X] = maxX > 0 ? maxX : 1080;
    dev.absmax[ABS_MT_POSITION_Y] = maxY > 0 ? maxY : 1920;
    dev.absmin[ABS_MT_POSITION_X] = 0;
    dev.absmin[ABS_MT_POSITION_Y] = 0;
    dev.absmax[ABS_MT_PRESSURE] = 255;
    dev.absmin[ABS_MT_PRESSURE] = 0;

    if (write(fd, &dev, sizeof(dev)) < 0) {
        LOGE("write uinput_user_dev failed: %s", strerror(errno));
        close(fd);
        return -1;
    }
    if (ioctl(fd, UI_DEV_CREATE) < 0) {
        LOGE("UI_DEV_CREATE failed: %s", strerror(errno));
        close(fd);
        return -1;
    }

    sleep_us(120 * 1000L); // 等设备节点注册完成
    LOGI("uinput device created, max=%dx%d", maxX, maxY);
    return fd;
}

jboolean JNICALL
Java_com_luma_clone_UinputInjector_nativeDrag(JNIEnv *env, jclass clazz, jint fd,
                                              jfloat x1, jfloat y1, jfloat x2, jfloat y2,
                                              jint durationMs) {
    (void) env; (void) clazz;
    if (fd < 0) return JNI_FALSE;

    int steps = durationMs > 0 ? durationMs / 2 : 1;
    if (steps < 1) steps = 1;
    if (steps > 32) steps = 32;

    emit(fd, EV_ABS, ABS_MT_SLOT, 0);
    emit(fd, EV_ABS, ABS_MT_TRACKING_ID, 1);
    emit(fd, EV_ABS, ABS_MT_PRESSURE, 128);
    emit(fd, EV_ABS, ABS_MT_POSITION_X, (int) x1);
    emit(fd, EV_ABS, ABS_MT_POSITION_Y, (int) y1);
    emit(fd, EV_KEY, BTN_TOUCH, 1);
    emit(fd, EV_SYN, SYN_REPORT, 0);

    for (int i = 1; i <= steps; i++) {
        float t = (float) i / (float) steps;
        int x = (int) (x1 + (x2 - x1) * t);
        int y = (int) (y1 + (y2 - y1) * t);
        emit(fd, EV_ABS, ABS_MT_POSITION_X, x);
        emit(fd, EV_ABS, ABS_MT_POSITION_Y, y);
        emit(fd, EV_SYN, SYN_REPORT, 0);
        sleep_us(2000);
    }

    emit(fd, EV_ABS, ABS_MT_TRACKING_ID, -1);
    emit(fd, EV_KEY, BTN_TOUCH, 0);
    emit(fd, EV_SYN, SYN_REPORT, 0);
    return JNI_TRUE;
}

void JNICALL
Java_com_luma_clone_UinputInjector_nativeClose(JNIEnv *env, jclass clazz, jint fd) {
    (void) env; (void) clazz;
    if (fd >= 0) {
        ioctl(fd, UI_DEV_DESTROY);
        close(fd);
    }
}
