#!/usr/bin/env bash
# 在 PC（Linux / macOS）上直接编译 APK
# 用法： bash build_apk.sh
set -e

SDK="$HOME/android-sdk"
if [ ! -d "$SDK/cmdline-tools/latest" ]; then
  echo "[*] downloading Android cmdline-tools ..."
  OS=$(uname -s | tr '[:upper:]' '[:lower:]')
  case "$OS" in
    linux*)  ZIP=commandlinetools-linux-11076708_latest.zip ;;
    darwin*) ZIP=commandlinetools-mac-11076708_latest.zip ;;
    *) echo "unsupported OS: $OS"; exit 1 ;;
  esac
  mkdir -p "$SDK/cmdline-tools"
  cd /tmp
  curl -LO "https://dl.google.com/android/repository/$ZIP"
  unzip -q -o "$ZIP"
  rm -rf "$SDK/cmdline-tools/latest"
  mv cmdline-tools "$SDK/cmdline-tools/latest"
fi

export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
export PATH="$PATH:$SDK/cmdline-tools/latest/bin:$SDK/platform-tools"

yes | sdkmanager --licenses >/dev/null 2>&1 || true
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0" \
           "ndk;26.1.10909125" "cmake;3.22.1" >/dev/null

cd "$(dirname "$0")"
echo "sdk.dir=$SDK" > local.properties

if [ ! -f gradle/wrapper/gradle-wrapper.jar ]; then
  echo "[*] generating gradle wrapper ..."
  command -v gradle >/dev/null || { echo "need 'gradle' on PATH or open in Android Studio"; exit 1; }
  gradle wrapper --gradle-version 8.7
fi

echo "[*] building ..."
./gradlew :app:assembleDebug --no-daemon --stacktrace

echo "[+] done:"
ls -lh app/build/outputs/apk/debug/ 2>/dev/null || true
