# YoloAim-Clone

Yolo Aim 0.4.66 的架构等价重写。无卡密、无网络授权、无签名校验、无原生保护。

## 1:1 映射

| 原 app（逆向所得） | 本工程 |
|---|---|
| com.luma.ai.core.CaptureService | ScreenCaptureService.kt（MediaProjection + VirtualDisplay + ImageReader）|
| libaimuinput.so（JNI 写 uinput） | TouchInjector.kt（root 注入 / 无障碍手势回退）|
| ncnn / onnxruntime / LiteRt + 私有模型 | Detector.kt（TFLite，可换 ncnn/ONNX）|
| com.luma.ai.ui.OverlayService | OverlayService.kt |
| IInjectorService（AIDL 跳进程） | 同进程直连 |
| LR0/d 授权闸 / 卡密 / 服务器同步 | 不存在（本项目核心差异）|

## 悬浮面板

- 可拖动（拖标题）、半透明
- 实时状态：模型是否加载 / 注入通道 / FPS / 推理耗时 / 目标数 / 运行状态
- 参数滑块（改完即时生效并持久化到 SharedPreferences）：
  - FOV：100–1000 px
  - 平滑：0.05–0.80
  - 瞭头比例：0.00–0.50

参数共享机制：`State.settings` 是同一个 `AimSettings` 实例，悬浮面板写、采集线程每帧读。

## 构建

1. Android Studio (AGP 8.x, JDK 17) 打开本目录。
2. 模型：`6AY_v26m_0917_256x256.onnx`（81,566,068 B，producer=pytorch 2.12，ir_version=7，输入名 `images`）
   已放在 `app/src/main/assets/model.onnx`（注意：APK 会因此变成 ~190 MB）。
   不想打包时改用运行时外挂：
   ```bash
   adb push 6AY_v26m_0917_256x256.onnx /sdcard/Android/data/com.luma.clone/files/model.onnx
   ```
   预处理与解码：
   - 输入尺寸运行时从 ORT `inputInfo` 读取（读不到则 256）
   - **letterbox**（等比缩放+灰边），坐标回映扣除 padding，非方形屏不偏
   - 输出自适应 `[1,C,N]` / `[1,N,C]`；`C==5` 单类目标度，`C>6` 多类取最大
3. `./gradlew :app:assembleDebug`

## 运行

1. 授予悬浮窗 + 通知 + （可选）无障碍。
2. 点“开始” → 系统屏录授权 → 启动采集服务。
3. 悬浮球：开始/暂停、FOV、平滑系数。

## 注入通道（三级后备）

| 优先级 | 通道 | 实现 | 前提 |
|---|---|---|---|
| 1 | uinput 内核事件 | `cpp/uinput_jni.c`（ABS_MT_SLOT/TRACKING_ID/POSITION，BTN_TOUCH） | 能打开 `/dev/uinput` |
| 2 | `su -c input swipe` | `TouchInjector.moveBy` | root |
| 3 | `dispatchGesture` | `AccessibilityInjector` | 无障碍服务 |

启动时自动探测：探不到 uinput 就用 `su -c 'chmod 666 /dev/uinput'` 再试一次，仍失败则逐级回退。

```bash
adb shell su -c 'chmod 666 /dev/uinput'   # 永久方案：Magisk 模块化授权
adb logcat -s Uinput TouchInjector       # 看 fd 与通道选择
```

## 已知缺口

- 不含任何私有模型权重，准确率取决于你自己放的模型。
- 未实现 QNN/NeuroPilot 硬件加速，可换 ncnn-vulkan / LiteRT GPU delegate。
- 无账号体系、无云端模型 —— 设计目标。

## 后处理（NMS + 置信度）

- `Detector` 内置**按类别贪心 NMS**（归一化坐标 IoU），阈值 `AimSettings.nmsIou`（默认 0.45）
- 置信度阈值 `AimSettings.confTh`（默认 0.35），面板滑块范围 **0.10–0.90**
- 两个阈值都持久化到 SharedPreferences（key: `conf` / `iou`）
- 流程：letterbox → ONNX 推理 → 逐格解码（自适应 `[1,C,N]`/`[1,N,C]`）→ 扣 padding 归一化 → NMS → 选靶

## 调试建议

| 现象 | 调法 |
|---|---|
| 目标数一直 0 | 置信度降到 0.15，确认模型是否真在出框 |
| 框很多但乱跳 | 置信度升到 0.5+，平滑降到 0.2 |
| 准心偏上/偏下 | 调瞄头比例（0 = 框中心，0.28 = 偏上） |
| 响应慢 | 关闭无障碍/root 通道，确认走 uinput；或把采集降到 720p |
