#!/data/data/com.termux/files/usr/bin/bash
# 在手机上直接编译 APK（Termux）
# 用法： bash build_apk_termux.sh
set -e

pkg update -y >/dev/null 2>&1 || true
pkg install -y openjdk-17 gradle wget unzip >/dev/null

SDK="$HOME/android-sdk"
if [ ! -d "$SDK/cmdline-tools/latest" ]; then
  echo "[*] installing Android cmdline-tools ..."
  mkdir -p "$SDK/cmdline-tools"
  cd /tmp
  wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  unzip -q -o commandlinetools-linux-11076708_latest.zip
  rm -rf "$SDK/cmdline-tools/latest"
  mv cmdline-tools "$SDK/cmdline-tools/latest"
fi

export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
export PATH="$PATH:$SDK/cmdline-tools/latest/bin:$SDK/platform-tools"

yes | sdkmanager --licenses >/dev/null 2>&1 || true
echo "[*] installing platform/build-tools/ndk/cmake ..."
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0" \
           "ndk;26.1.10909125" "cmake;3.22.1" >/dev/null

cd "$(dirname "$0")"
echo "sdk.dir=$SDK" > local.properties

echo "[*] building ..."
gradle :app:assembleDebug --no-daemon --stacktrace

APK="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
  echo "[+] built: $PWD/$APK"
  ls -lh "$APK"
  # 自动弹出系统安装器
  termux-open "$APK" 2>/dev/null || echo "[*] 手动安装：$PWD/$APK"
else
  echo "[x] build failed, 把上面报错贴回给助手"
  exit 1
fi
